defmodule RestApi do
  @moduledoc """
  Documentation for `RestApi`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> RestApi.hello()
      :world

  """
  def hello do
    :world
  end
end
